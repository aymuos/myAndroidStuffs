package com.aymuos.foodsandforkapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class LogInActivity : AppCompatActivity() , View.OnClickListener {
    override fun onClick(p0:View?){
        Toast.makeText(this@LogInActivity,"Succesfully LoggediN",Toast.LENGTH_LONG).show()
    }

    lateinit var etEmailInput:EditText
    lateinit var etPassword:EditText
    lateinit var btnLoginMain:EditText
    lateinit var txt3:EditText
    lateinit var txt4:EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

        title="LogIn"
        etEmailInput=findViewById(R.id.etEmailInput)
        etPassword=findViewById(R.id.etPasswrd)
        btnLoginMain=findViewById(R.id.btnLoginMain)
        txt3=findViewById(R.id.txt3)
        txt4=findViewById(R.id.txt4)

        btnLoginMain.setOnClickListener(this)
    }
}